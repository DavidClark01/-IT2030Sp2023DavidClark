﻿namespace TipCalculator.Controllers
{
    public class HomeControllerBase
    {
    }
}