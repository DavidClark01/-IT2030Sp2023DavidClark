﻿namespace David_s_Extreme_Gear.Views.Contact
{
    public class contactmodel
    {
        internal dynamic ContactModel()
        {
            throw new NotImplementedException();
        }
    }
}