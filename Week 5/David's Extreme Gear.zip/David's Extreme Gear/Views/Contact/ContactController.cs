﻿using Microsoft.AspNetCore.Mvc;

namespace David_s_Extreme_Gear.Views.Contact
{
    public class ContactController : Controller
    {


        [HttpGet]
        public IActionResult Index()
        {
            ViewBag.FV = 0;
            return View();
        }
        [HttpPost]
        public IActionResult Index(contactmodel model)
        {
            ViewBag.FV = model.ContactModel();
            return View(model);
        }


    }
}