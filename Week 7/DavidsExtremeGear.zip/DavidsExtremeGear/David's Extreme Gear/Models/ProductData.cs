﻿using System.Reflection.Metadata.Ecma335;

namespace David_s_Extreme_Gear.Models
{
    public class ProductData
    {
        public static List<ProductModel> GetProducts()
        {
            List<ProductModel> products = new List<ProductModel>
        {
            new ProductModel
            {
                ProductId = 1,
                ProductName = "Ball",
                ProductDescription = "Soccer Ball",
                ProductImage = "Soccer.jpg",
                ProductPrice = 1528
            },
            new ProductModel
            {
                ProductId = 3,
                ProductName = "Pick",
                ProductDescription = "Hiking Equipment",
                ProductImage = "Pick.png",
                ProductPrice = 1965
            },
            new ProductModel
            {
                ProductId = 3,
                ProductName = "Bat",
                ProductDescription = "Baseball Bat",
                ProductImage = "Bat.jpg",
                ProductPrice = 756
            }
        };
            return products;
        }

        public static ProductModel GetProduct(int Id)
        {
            List<ProductModel> products = ProductData.GetProducts();
            foreach (ProductModel product in products)
            {
                if (product.ProductId == Id)
                {
                    return product;
                }
            }
            return new ProductModel();
        }
    }
}
