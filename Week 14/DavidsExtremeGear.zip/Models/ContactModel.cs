﻿using System.ComponentModel.DataAnnotations;

//namespace David_s_Extreme_Gear.Views.Contact
namespace David_s_Extreme_Gear.Models
{
    public class ContactModel
    {






        [Key]
        public int ContactId { get; set; }

        [Required(ErrorMessage = "Please enter your first name.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please enter your first last name.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Please enter your email address.")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter a phone number.")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Please enter a message.")]
        [StringLength(5000, ErrorMessage = "The message cannot be longer than 5000 characters.")]
        public string Message { get; set; }

        [Required(ErrorMessage = "Please enter an address.")]
        public string Address { get; set; }
    }
}