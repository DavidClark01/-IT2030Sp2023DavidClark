﻿
using David_s_Extreme_Gear.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;


namespace David_s_Extreme_Gear.Controllers
{

        public class HomeController : Controller
        {
            private readonly ILogger<HomeController> _logger;
        //private readonly MySession _session; //remove this line it is causing errors

        // public HomeController(ILogger<HomeController> logger, MySession session)  //remove this line it is causing errors
        public HomeController(ILogger<HomeController> logger)
            {
                _logger = logger;
            //_session = session;  //remove this line it is causing errors
        }
        public IActionResult Index()
            {
                return View();
            }

            public IActionResult Privacy()
            {
                return View();
            }
            public IActionResult About()
            {
                return View();
            }
            [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
            public IActionResult Error()
            {
                return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
            }


        public IActionResult Events()
        {
            return View();
        }


        public IActionResult Tools()
            {
                // Set session variable
                HttpContext.Session.SetString("FirstName", "David");

            // Retrieve session variable
            // _ = HttpContext.Session.GetString("FirstName"); //remove this line it is causing errors

            HttpContext.Session.GetString("FirstName");

            return View();
            }

            [HttpPost]
            public IActionResult ClearTools()
            {
                // Clear session variable
                HttpContext.Session.Remove("FirstName");

                return View("Tools");
            }

        }
    }







