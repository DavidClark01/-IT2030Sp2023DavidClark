﻿using David_s_Extreme_Gear.Models;
using Microsoft.EntityFrameworkCore;

namespace David_s_Extreme_Gear.Data
{
    public class DavidsExtremeGearContext : DbContext
    {
        public DavidsExtremeGearContext(DbContextOptions<DavidsExtremeGearContext> options)
            : base(options)
        {
        }

        
        public DbSet<ContactModel> ContactDb { get; set; }
        public DbSet<ProductModel> ProductDb { get; set; }
    }
}
