//using David_s_Extreme_Gear.Data;
//using David_s_Extreme_Gear.Models;
//using Microsoft.AspNetCore.Builder;
//using Microsoft.AspNetCore.Hosting;
//using Microsoft.EntityFrameworkCore;
//using Microsoft.Extensions.Configuration;
//using Microsoft.Extensions.DependencyInjection;
//using Microsoft.Extensions.Hosting;
//using System;

//namespace DavidsExtremeGear
//{
//    public class Program
//    {
//        public static void Main(string[] args)
//        {
//            CreateHostBuilder(args).Build().Run();
//        }

//        public static IHostBuilder CreateHostBuilder(string[] args) =>
//            Host.CreateDefaultBuilder(args)
//                .ConfigureServices((hostContext, services) =>
//                {
//                    services.AddDbContext<DavidsExtremeGearContext>(options =>
//                        options.UseSqlServer(hostContext.Configuration.GetConnectionString("ProductDb")));

//                    services.AddControllersWithViews();
//                });
//    }

//    public class Startup
//    {
//        private readonly IConfiguration Configuration;

//        public Startup(IConfiguration configuration)
//        {
//            Configuration = configuration;
//        }

//        public void ConfigureServices(IServiceCollection services)
//        {
//            services.AddControllersWithViews();
//            services.AddApplicationInsightsTelemetry();
//            services.AddMemoryCache();
//            services.AddHttpContextAccessor();

//            services.AddSession(options =>
//            {
//                options.IdleTimeout = TimeSpan.FromMinutes(30);
//            });

//            services.AddSingleton<MySession>();
//            services.AddDbContext<DavidsExtremeGearContext>(options =>
//                options.UseSqlServer(Configuration.GetConnectionString("ProductDb")));
//        }

//        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
//        {
//            if (env.IsDevelopment())
//            {
//                app.UseDeveloperExceptionPage();
//            }
//            else
//            {
//                app.UseExceptionHandler("/Home/Error");
//                app.UseHsts();
//            }

//            app.UseHttpsRedirection();
//            app.UseStaticFiles();
//            app.UseRouting();
//            app.UseSession();
//            app.UseAuthorization();

//            app.UseEndpoints(endpoints =>
//            {
//                endpoints.MapControllerRoute(
//                    name: "default",
//                    pattern: "{controller=Home}/{action=Index}/{id?}");
//            });
//        }
//    }
//}
// remove lines 1-84

using David_s_Extreme_Gear.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using David_s_Extreme_Gear.Data;


var builder = WebApplication.CreateBuilder(args);

//add session state services for the app here
builder.Services.AddMemoryCache();
builder.Services.AddSession();

//Session options
//builder.Services.AddSession(options =>
//{   //change idle timeout to 5 minutes - default is 20 minutes
//    options.IdleTimeout = TimeSpan.FromSeconds(60 * 5);
//    options.Cookie.HttpOnly = false;        //default is true
//    options.Cookie.IsEssential = true;      //default is false
//}) ;        //can change default options see page 333


// Add services to the container.
builder.Services.AddControllersWithViews();

// Add EF Core DI ---added
builder.Services.AddDbContext<DavidsExtremeGearContext>(options =>
   options.UseSqlServer(builder.Configuration.GetConnectionString("DavidsExtremeGearContext") ?? throw new InvalidOperationException("Connection string 'DavidsExtremeGearContext' not found.")));

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

//add service to use for session state here
app.UseSession();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();

