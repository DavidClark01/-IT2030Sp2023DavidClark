﻿
using David_s_Extreme_Gear.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;


namespace David_s_Extreme_Gear.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult About()
        {
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        private readonly MySession _session;

        public HomeController(MySession session)
        {
            _session = session;
        }

        public IActionResult Tools()
        {
            return View();
        }

        [HttpPost]
        public IActionResult SetSessionValues()
        {
            _session.FirstName = "David";
            _session.LastName = "Clark";
            _session.Course = "IT2030";
            _session.FavNum = 42;

            return RedirectToAction("Tools");
        }

        [HttpPost]
        public IActionResult GetSessionValues()
        {
            ViewBag.FirstName = _session.FirstName;
            ViewBag.LastName = _session.LastName;
            ViewBag.Course = _session.Course;
            ViewBag.FavNum = _session.FavNum;

            return View("Tools");
        }
    }
}



