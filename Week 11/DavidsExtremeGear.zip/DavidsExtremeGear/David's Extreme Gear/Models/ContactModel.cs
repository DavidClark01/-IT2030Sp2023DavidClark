﻿using System.ComponentModel.DataAnnotations;

//namespace David_s_Extreme_Gear.Views.Contact
namespace David_s_Extreme_Gear.Models
{
    public class ContactModel
    {
  




[Required(ErrorMessage = "Please enter your first name.")]
        [StringLength(30, ErrorMessage = "First name cannot exceed 30 characters.")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "First name cannot contain special characters or numbers.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please enter your last name.")]
        [StringLength(30, ErrorMessage = "Last name cannot exceed 30 characters.")]
        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Last name cannot contain special characters or numbers.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Please enter an address.")]
        public string? Address { get; set; } = string.Empty;

        [Required(ErrorMessage = "Please enter your phone number.")]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Please enter a valid 10-digit phone number.")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Please enter your email address.")]
        [EmailAddress(ErrorMessage = "Please enter a valid email address.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter a message.")]
        public string? Message { get; set; } = string.Empty;
    }
}