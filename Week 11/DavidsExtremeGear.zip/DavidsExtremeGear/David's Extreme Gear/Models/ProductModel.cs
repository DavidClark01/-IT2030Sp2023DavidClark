﻿using System.ComponentModel.DataAnnotations;

namespace David_s_Extreme_Gear.Models
{
    public class ProductModel
    {
        
    [Required(ErrorMessage = "Please enter a product name.")]
        public string ProductName { get; set; }

        [Required(ErrorMessage = "Please enter a product description.")]
        public string ProductDescription { get; set; }

        [Required(ErrorMessage = "Please select a product image.")]
        public string ProductImage { get; set; }

        [Required(ErrorMessage = "Please enter a product price.")]
        [DataType(DataType.Currency)]
        public decimal ProductPrice { get; set; }
        public int ProductId { get; internal set; }
    }
}

